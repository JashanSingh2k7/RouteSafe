"""
services/optimizer.py

L4 — Route Optimizer

Consumes L3 scored segments + L2 hazard grids and generates avoidance
waypoints that steer the route through minimum-risk corridors.

Algorithm (iterative greedy with hex-grid pathfinding):
    1. Identify contiguous high-risk clusters from scored segments
    2. For the worst cluster, extract entry/exit points
    3. Run Dijkstra on the H3 hex grid from entry→exit, weighted by severity
    4. Convert the minimum-risk hex path into a lat/lon waypoint
    5. Re-score the adjusted route and repeat until acceptable or max iterations

Consumed by: routers/optimizer.py (endpoint)
"""

import math
import heapq
import logging
from dataclasses import dataclass, field
from typing import Optional

import h3

from models.schemas import RouteSegment, ScoredSegment, OptimizedRoute
from services.hazard_field import H3_RESOLUTION, TIME_HORIZONS_HOURS
from services.route_scorer import (
    score_route,
    RISK_THRESHOLDS,
    _haversine_km,
)

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────────────────────────────────────

AVOIDANCE_THRESHOLD: float = RISK_THRESHOLDS["moderate"]  # 0.40
CLUSTER_GAP_TOLERANCE: int = 2
SEARCH_RINGS: int = 12
MAX_ITERATIONS: int = 5
MAX_DETOUR_FACTOR: float = 2.5
BASE_HEX_COST: float = 0.01
ANCHOR_BUFFER_KM: float = 5.0


# ─────────────────────────────────────────────────────────────────────────────
# DATA STRUCTURES
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RiskCluster:
    start_index:    int
    end_index:      int
    peak_risk:      float
    avg_risk:       float
    entry_lat:      float
    entry_lon:      float
    exit_lat:       float
    exit_lon:       float
    segment_count:  int


@dataclass(order=True)
class _DijkstraNode:
    cost: float
    hex_id: str = field(compare=False)
    parent: Optional[str] = field(default=None, compare=False)


# ─────────────────────────────────────────────────────────────────────────────
# CLUSTER DETECTION
# ─────────────────────────────────────────────────────────────────────────────

def _find_risk_clusters(
    segments: list[ScoredSegment],
    threshold: float = AVOIDANCE_THRESHOLD,
    gap_tolerance: int = CLUSTER_GAP_TOLERANCE,
) -> list[RiskCluster]:
    hot_indices = [s.index for s in segments if s.risk_score >= threshold]
    if not hot_indices:
        return []

    seg_map = {s.index: s for s in segments}
    clusters_raw: list[list[int]] = []
    current_group: list[int] = [hot_indices[0]]

    for idx in hot_indices[1:]:
        if idx - current_group[-1] <= gap_tolerance:
            current_group.append(idx)
        else:
            clusters_raw.append(current_group)
            current_group = [idx]
    clusters_raw.append(current_group)

    clusters: list[RiskCluster] = []
    for group in clusters_raw:
        group_segs = [seg_map[i] for i in group if i in seg_map]
        if not group_segs:
            continue

        risks = [s.risk_score for s in group_segs]
        first_idx = group[0]
        entry_seg = seg_map.get(max(first_idx - 1, 0), group_segs[0])
        last_idx = group[-1]
        max_idx = max(seg_map.keys())
        exit_seg = seg_map.get(min(last_idx + 1, max_idx), group_segs[-1])

        clusters.append(RiskCluster(
            start_index=first_idx, end_index=last_idx,
            peak_risk=max(risks), avg_risk=sum(risks) / len(risks),
            entry_lat=entry_seg.start_lat, entry_lon=entry_seg.start_lon,
            exit_lat=exit_seg.end_lat, exit_lon=exit_seg.end_lon,
            segment_count=len(group_segs),
        ))

    clusters.sort(key=lambda c: c.peak_risk, reverse=True)
    return clusters


# ─────────────────────────────────────────────────────────────────────────────
# H3 HEX-GRID DIJKSTRA
# ─────────────────────────────────────────────────────────────────────────────

def _hex_severity(hex_id: str, hex_grid: dict[str, float]) -> float:
    return hex_grid.get(hex_id, 0.0)


def _dijkstra_hex_path(
    start_hex: str, goal_hex: str,
    hex_grid: dict[str, float],
    max_rings: int = SEARCH_RINGS,
) -> Optional[list[str]]:
    if start_hex == goal_hex:
        return [start_hex]

    mid_lat = (h3.cell_to_latlng(start_hex)[0] + h3.cell_to_latlng(goal_hex)[0]) / 2
    mid_lon = (h3.cell_to_latlng(start_hex)[1] + h3.cell_to_latlng(goal_hex)[1]) / 2
    mid_hex = h3.latlng_to_cell(mid_lat, mid_lon, H3_RESOLUTION)

    try:
        direct_dist = h3.grid_distance(start_hex, goal_hex)
    except h3.H3ResDomainError:
        s_ll = h3.cell_to_latlng(start_hex)
        g_ll = h3.cell_to_latlng(goal_hex)
        dist_km = _haversine_km(s_ll[0], s_ll[1], g_ll[0], g_ll[1])
        direct_dist = int(dist_km / 2.6) + 1

    search_radius = min(max(max_rings, direct_dist + 6), 40)

    allowed_hexes = set(h3.grid_disk(mid_hex, search_radius))
    allowed_hexes.update(h3.grid_disk(start_hex, 4))
    allowed_hexes.update(h3.grid_disk(goal_hex, 4))

    dist_map: dict[str, float] = {start_hex: 0.0}
    parent_map: dict[str, Optional[str]] = {start_hex: None}
    pq: list[_DijkstraNode] = [_DijkstraNode(cost=0.0, hex_id=start_hex)]
    visited: set[str] = set()

    while pq:
        node = heapq.heappop(pq)
        if node.hex_id in visited:
            continue
        visited.add(node.hex_id)

        if node.hex_id == goal_hex:
            path = []
            current = goal_hex
            while current is not None:
                path.append(current)
                current = parent_map[current]
            path.reverse()
            return path

        for neighbor in h3.grid_disk(node.hex_id, 1):
            if neighbor == node.hex_id or neighbor in visited:
                continue
            if neighbor not in allowed_hexes:
                continue

            sev = _hex_severity(neighbor, hex_grid)
            edge_cost = (sev ** 2) + BASE_HEX_COST
            new_cost = node.cost + edge_cost

            if new_cost < dist_map.get(neighbor, float("inf")):
                dist_map[neighbor] = new_cost
                parent_map[neighbor] = node.hex_id
                heapq.heappush(pq, _DijkstraNode(cost=new_cost, hex_id=neighbor))

    logger.warning("Dijkstra found no path from %s to %s", start_hex, goal_hex)
    return None


# ─────────────────────────────────────────────────────────────────────────────
# WAYPOINT EXTRACTION
# ─────────────────────────────────────────────────────────────────────────────

def _hex_path_to_waypoints(hex_path: list[str], max_waypoints: int = 3) -> list[dict[str, float]]:
    if len(hex_path) <= 2:
        return []

    inner = hex_path[1:-1]
    if not inner:
        return []

    n = min(max_waypoints, len(inner))
    step = len(inner) / (n + 1)
    indices = [min(int(step * (i + 1)), len(inner) - 1) for i in range(n)]

    waypoints = []
    for idx in indices:
        lat, lon = h3.cell_to_latlng(inner[idx])
        waypoints.append({"lat": round(lat, 6), "lon": round(lon, 6)})
    return waypoints


def _path_total_severity(hex_path: list[str], hex_grid: dict[str, float]) -> float:
    return sum(_hex_severity(h, hex_grid) for h in hex_path)


# ─────────────────────────────────────────────────────────────────────────────
# MAIN OPTIMIZER
# ─────────────────────────────────────────────────────────────────────────────

def optimize_route(
    scored_segments: list[ScoredSegment],
    grids_by_time: dict[float, dict[str, float]],
    flat_grid: dict[str, float],
    health_profile: str = "default",
    threshold: float = AVOIDANCE_THRESHOLD,
    max_iterations: int = MAX_ITERATIONS,
) -> dict:
    logger.info(
        "optimize_route() — %d segments, threshold=%.2f, max_iter=%d",
        len(scored_segments), threshold, max_iterations,
    )

    all_waypoints: list[dict[str, float]] = []
    avoidance_details: list[dict] = []
    working_segments = list(scored_segments)

    for iteration in range(max_iterations):
        clusters = _find_risk_clusters(working_segments, threshold)
        if not clusters:
            logger.info("Iteration %d: no more risk clusters. Done.", iteration)
            break

        cluster = clusters[0]
        logger.info(
            "Iteration %d: fixing cluster [%d→%d] peak=%.3f avg=%.3f (%d segs)",
            iteration, cluster.start_index, cluster.end_index,
            cluster.peak_risk, cluster.avg_risk, cluster.segment_count,
        )

        mid_seg_idx = (cluster.start_index + cluster.end_index) // 2
        mid_seg = next((s for s in working_segments if s.index == mid_seg_idx), working_segments[0])
        cum_hours = mid_seg.cumulative_time_min / 60.0

        available = sorted(grids_by_time.keys()) if grids_by_time else [0]
        best_bucket = min(available, key=lambda h: abs(h - cum_hours))
        hex_grid = grids_by_time.get(best_bucket, flat_grid)

        start_hex = h3.latlng_to_cell(cluster.entry_lat, cluster.entry_lon, H3_RESOLUTION)
        goal_hex = h3.latlng_to_cell(cluster.exit_lat, cluster.exit_lon, H3_RESOLUTION)

        hex_path = _dijkstra_hex_path(start_hex, goal_hex, hex_grid)

        if not hex_path:
            logger.warning("No avoidance path found for cluster [%d→%d], skipping.",
                           cluster.start_index, cluster.end_index)
            for seg in working_segments:
                if cluster.start_index <= seg.index <= cluster.end_index:
                    seg.risk_score = max(seg.risk_score * 0.95, 0.0)
            continue

        original_sev = _path_total_severity(
            [h3.latlng_to_cell(s.start_lat, s.start_lon, H3_RESOLUTION)
             for s in working_segments if cluster.start_index <= s.index <= cluster.end_index],
            hex_grid,
        )
        new_sev = _path_total_severity(hex_path, hex_grid)

        if new_sev >= original_sev * 0.9:
            for seg in working_segments:
                if cluster.start_index <= seg.index <= cluster.end_index:
                    seg.risk_score = max(seg.risk_score * 0.95, 0.0)
            continue

        direct_km = _haversine_km(
            cluster.entry_lat, cluster.entry_lon, cluster.exit_lat, cluster.exit_lon,
        )
        detour_km = sum(
            _haversine_km(*h3.cell_to_latlng(hex_path[i]), *h3.cell_to_latlng(hex_path[i + 1]))
            for i in range(len(hex_path) - 1)
        )

        if direct_km > 0 and detour_km / direct_km > MAX_DETOUR_FACTOR:
            for seg in working_segments:
                if cluster.start_index <= seg.index <= cluster.end_index:
                    seg.risk_score = max(seg.risk_score * 0.95, 0.0)
            continue

        waypoints = _hex_path_to_waypoints(hex_path, max_waypoints=3)
        if not waypoints:
            continue

        all_waypoints.extend(waypoints)
        avoidance_details.append({
            "cluster_start": cluster.start_index,
            "cluster_end": cluster.end_index,
            "cluster_peak_risk": round(cluster.peak_risk, 4),
            "hex_path_length": len(hex_path),
            "waypoints": waypoints,
            "original_severity_sum": round(original_sev, 3),
            "new_severity_sum": round(new_sev, 3),
            "detour_km": round(detour_km, 2),
            "direct_km": round(direct_km, 2),
        })

        for seg in working_segments:
            if cluster.start_index <= seg.index <= cluster.end_index:
                seg.risk_score = new_sev / max(len(hex_path), 1)

    remaining_max = max((s.risk_score for s in working_segments), default=0.0)

    return {
        "waypoints": all_waypoints,
        "clusters_found": len(_find_risk_clusters(scored_segments, threshold)),
        "clusters_resolved": len(avoidance_details),
        "avoidance_details": avoidance_details,
        "rerouted": len(all_waypoints) > 0,
        "remaining_max_risk": round(remaining_max, 4),
    }